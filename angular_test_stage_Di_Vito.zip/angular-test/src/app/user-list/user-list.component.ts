import { Component, OnInit } from '@angular/core';


import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})

export class UserListComponent implements OnInit {
  query:any;
  public users: any = [];
  public length: any = [];
  constructor(public http: HttpClient) { }

  ngOnInit(): void {
    this.recupUsers();
  }

  public recupUsers():void{
    let data: Observable<any>;
    let i: number = 1;
 
    do {
      data = this.http.get('https://swapi.co/api/people/?page='+i)
      data.subscribe(
        tab =>{
          this.users.push(tab.results);
        },    
      );
      i++;
    } while ( i < 9)
  }
}
